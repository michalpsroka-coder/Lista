ARCHIVE OF FALLEN — wersja Dark Fantasy

To jest odświeżony wygląd strony z zachowaniem:
- wspólnej listy bossów przez Supabase,
- logowania administratora,
- osobnych gier,
- statusu pokonania,
- obrazków bossów,
- uprawnień tylko dla administratora.

W pliku index.html znajdziesz dwa pola:
SUPABASE_URL
SUPABASE_KEY

Wklej tam te same wartości, które masz w działającej wersji.

Następnie podmień index.html w repozytorium GitHub Pages i zrób Commit changes.

Styl jest inspirowany mrocznym, gotyckim fantasy: kamień, złoto, popiół, żar, ornamenty i typografia szeryfowa. Nie wykorzystuje logo ani grafik z gry.
